import { useEffect, useState } from "react";
import { Device } from "@capacitor/device";
import { ThemeProvider } from "@emotion/react";
import styled from "@emotion/styled";
import { Box, Container, createTheme, CssBaseline, Stack, Typography } from "@mui/material";

import { AlertHandler } from "./components/Common/Alert/AlertHandler";
import { Analytics } from "./components/Common/Analytics";
import BottomActions from "./components/Common/BottomActions";
import { ConfigProvider } from "./components/Config/Provider";
import { HistoryProvider } from "./components/History/Provider";
import ShazarrButton from "./components/Shazarr/Button";
import { ShazarrProvider } from "./components/Shazarr/Provider";
import ShazarrResults from "./components/Shazarr/Result";
import StatusChip from "./components/Shazarr/ui/StatusChip";

const darkTheme = createTheme({
  palette: {
    mode: "dark",
    background: {
      default: "#153b50",
      paper: "#0a1d28",
    },
  },
});

function App() {
  const [devideOS, setDevideOS] = useState<"ios" | "android" | "web">();

  useEffect(() => {
    Device.getInfo().then(({ platform }) => setDevideOS(platform));
  }, []);

  return (
    <ThemeProvider theme={darkTheme}>
      <ConfigProvider>
        <HistoryProvider>
          <ShazarrProvider>
            <CssBaseline />
            <Analytics />
            <Main>
              <Container>
                <StackStyled direction="column" os={devideOS}>
                  <Box>
                    <H1>Shazarr</H1>
                    <Typography component="h2" sx={{ marginBottom: 2 }}>
                      - Offroad Shazam app -
                    </Typography>
                    <StatusChip />
                  </Box>
                  <Box
                    sx={{
                      marginTop: 3,
                      flex: "1 1 0",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <ShazarrButton />
                  </Box>
                  <AlertHandler />
                </StackStyled>
              </Container>
              <ShazarrResults />
              <BottomActions />
            </Main>
          </ShazarrProvider>
        </HistoryProvider>
      </ConfigProvider>
    </ThemeProvider>
  );
}

export default App;

const H1 = styled.h1`
  letter-spacing: 4px;
  margin-bottom: 0;
  text-transform: uppercase;
`;

const Main = styled.main`
  background-image: linear-gradient(180deg, #153b50 0%, #0a1d28 100%);
  display: flex;
  margin: 0;
  text-align: center;
  min-height: 100vh;
`;

const StackStyled = styled(Stack)<{
  os: "ios" | "android" | "web" | undefined;
}>`
  min-height: 100vh;
  padding: ${({ os }) => (os === "ios" ? "3rem 0" : 0)};
`;
